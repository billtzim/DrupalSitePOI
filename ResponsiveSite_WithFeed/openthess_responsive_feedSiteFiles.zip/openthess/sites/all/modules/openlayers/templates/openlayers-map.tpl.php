<div style="width:<?php print $variables['container']['width'];?>;height:<?php print $variables['container']['height'];?>;" id="<?php print $variables['container']['id'];?>" class="<?php print $variables['container']['classes']; ?>">
  <?php print $links; ?>
  <div style="width:<?php print $variables['container']['width'];?>;height:<?php print $variables['container']['height'];?>;" id="<?php print $map['id'];?>" class="<?php print $classes; ?>"></div>
</div>
