Default image set for the OpenLayers Drupal module.

Many original images used with permission (and licensed under GPL)
from MapBox.

https://github.com/developmentseed/openlayers_themes