
/**
 * OpenLayers Dummy Layer Handler
 */
Drupal.openlayers.layer.dummy = function(title, map, options) {
  return new OpenLayers.Layer(title, options);
};
