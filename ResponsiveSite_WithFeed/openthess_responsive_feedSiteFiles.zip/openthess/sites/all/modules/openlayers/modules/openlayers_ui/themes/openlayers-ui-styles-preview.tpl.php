<div id="<?php print $style->name; ?>" class="openlayers-ui-style-preview"></div>
